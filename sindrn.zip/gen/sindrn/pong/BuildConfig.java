/** Automatically generated file. DO NOT MODIFY */
package sindrn.pong;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}